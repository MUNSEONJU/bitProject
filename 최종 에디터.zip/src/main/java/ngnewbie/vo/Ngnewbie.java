package ngnewbie.vo;

public class Ngnewbie {
  private int no;
  private String urlhash;
  private String config;
  private String html;
  private String js;
  
  public String getConfig() {
    return config;
  }
  public void setConfig(String config) {
    this.config = config;
  }
  public String getUrlhash() {
    return urlhash;
  }
  public void setUrlhash(String urlhash) {
    this.urlhash = urlhash;
  }
  public int getNo() {
    return no;
  }
  public void setNo(int no) {
    this.no = no;
  }
  public String getHtml() {
    return html;
  }
  public void setHtml(String html) {
    this.html = html;
  }
  public String getJs() {
    return js;
  }
  public void setJs(String js) {
    this.js = js;
  }
  
}
